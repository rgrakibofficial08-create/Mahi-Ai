package com.example.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

class MahiVoiceManager(private val context: Context) : TextToSpeech.OnInitListener {

    companion object {
        private const val TAG = "MahiVoiceManager"
        const val UTTERANCE_ID = "Mahi_Speech"
    }

    private var tts: TextToSpeech? = null
    private var isTtsReady = false

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

    private val _isListening = MutableStateFlow(false)
    val isListening: StateFlow<Boolean> = _isListening.asStateFlow()

    private val _rmsLevel = MutableStateFlow(0f)
    val rmsLevel: StateFlow<Float> = _rmsLevel.asStateFlow()

    private val _recognizedText = MutableStateFlow("")
    val recognizedText: StateFlow<String> = _recognizedText.asStateFlow()

    var speechPitch: Float = 1.20f // Natural youthful female voice register
    var speechRate: Float = 1.0f

    private var speechRecognizer: SpeechRecognizer? = null

    init {
        tts = TextToSpeech(context.applicationContext, this)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            isTtsReady = true
            configureFemaleVoice(isBengali = true)
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    _isSpeaking.value = true
                }

                override fun onDone(utteranceId: String?) {
                    _isSpeaking.value = false
                }

                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    _isSpeaking.value = false
                }
            })
            Log.d(TAG, "TTS initialized successfully with female voice configuration.")
        } else {
            Log.e(TAG, "TTS initialization failed: $status")
        }
    }

    fun configureFemaleVoice(isBengali: Boolean) {
        if (!isTtsReady || tts == null) return

        val targetLocale = if (isBengali) {
            val bd = Locale("bn", "BD")
            val available = tts?.isLanguageAvailable(bd)
            if (available == TextToSpeech.LANG_AVAILABLE || available == TextToSpeech.LANG_COUNTRY_AVAILABLE) {
                bd
            } else {
                Locale("bn", "IN")
            }
        } else {
            Locale.US
        }

        try {
            tts?.language = targetLocale
            // Natural female pitch adjustment (standard is 1.0f; 1.15-1.25 creates a clear female voice tone)
            tts?.setPitch(speechPitch)
            tts?.setSpeechRate(speechRate)

            // Select explicitly tagged female voice if available from TTS engine
            val voices: Set<Voice>? = tts?.voices
            if (!voices.isNullOrEmpty()) {
                val femaleVoice = voices.firstOrNull { v ->
                    val name = v.name.lowercase()
                    v.locale.language == targetLocale.language &&
                    (name.contains("female") || name.contains("woman") || name.contains("-sfg-") || name.contains("-network"))
                } ?: voices.firstOrNull { it.locale.language == targetLocale.language }

                if (femaleVoice != null) {
                    tts?.voice = femaleVoice
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Error selecting female voice", e)
        }
    }

    fun speak(text: String, isBengali: Boolean, onDone: (() -> Unit)? = null) {
        if (!isTtsReady || tts == null) {
            Log.w(TAG, "TTS not ready yet")
            return
        }

        // Clean markdown characters like asterisks before speaking
        val cleanText = text
            .replace(Regex("[*#_`~]"), "")
            .replace(Regex("https?://\\S+"), "")
            .trim()

        if (cleanText.isBlank()) return

        configureFemaleVoice(isBengali)
        tts?.speak(cleanText, TextToSpeech.QUEUE_FLUSH, null, UTTERANCE_ID)
    }

    fun stopSpeaking() {
        if (tts?.isSpeaking == true) {
            tts?.stop()
        }
        _isSpeaking.value = false
    }

    fun startListening(
        isBengali: Boolean,
        onResult: (String) -> Unit,
        onError: (String) -> Unit
    ) {
        stopSpeaking()
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            onError(if (isBengali) "স্পীচ রিকগনিশন এই ডিভাইসে সাপোর্ট করছে না।" else "Speech recognition not available on this device.")
            return
        }

        speechRecognizer?.destroy()
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {
                    _isListening.value = true
                    _rmsLevel.value = 0.2f
                }

                override fun onBeginningOfSpeech() {
                    _isListening.value = true
                }

                override fun onRmsChanged(rmsdB: Float) {
                    // Normalize RMS to 0.0 - 1.0 range
                    val normalized = ((rmsdB + 2f) / 12f).coerceIn(0.1f, 1f)
                    _rmsLevel.value = normalized
                }

                override fun onBufferReceived(buffer: ByteArray?) {}

                override fun onEndOfSpeech() {
                    _isListening.value = false
                    _rmsLevel.value = 0f
                }

                override fun onError(error: Int) {
                    _isListening.value = false
                    _rmsLevel.value = 0f
                    val errMsg = when (error) {
                        SpeechRecognizer.ERROR_NO_MATCH -> if (isBengali) "কোনো কথা বোঝা যায়নি, আবার বলুন।" else "No speech heard, please try again."
                        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> if (isBengali) "সময় শেষ হয়েছে।" else "Speech timed out."
                        SpeechRecognizer.ERROR_AUDIO -> if (isBengali) "অডিও রেকর্ডিং সমস্যা।" else "Audio recording error."
                        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> if (isBengali) "ইন্টারনেট কানেকশন চেক করুন।" else "Network error."
                        else -> if (isBengali) "ভয়েস শুনতে পাইনি।" else "Voice recognition error."
                    }
                    onError(errMsg)
                }

                override fun onResults(results: Bundle?) {
                    _isListening.value = false
                    _rmsLevel.value = 0f
                    val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val spoken = matches?.firstOrNull() ?: ""
                    if (spoken.isNotBlank()) {
                        _recognizedText.value = spoken
                        onResult(spoken)
                    } else {
                        onError(if (isBengali) "কথা শোনা যায়নি।" else "No words recognized.")
                    }
                }

                override fun onPartialResults(partialResults: Bundle?) {
                    val partial = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (!partial.isNullOrBlank()) {
                        _recognizedText.value = partial
                    }
                }

                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
        }

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            val langTag = if (isBengali) "bn-BD" else "en-US"
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, langTag)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, langTag)
            putExtra(RecognizerIntent.EXTRA_ONLY_RETURN_LANGUAGE_PREFERENCE, false)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        }

        try {
            speechRecognizer?.startListening(intent)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to start listening", e)
            _isListening.value = false
            onError(e.message ?: "Could not start microphone")
        }
    }

    fun stopListening() {
        try {
            speechRecognizer?.stopListening()
        } catch (e: Exception) {
            Log.w(TAG, "Error stopping recognizer", e)
        }
        _isListening.value = false
        _rmsLevel.value = 0f
    }

    fun testFemaleVoice(isBengali: Boolean) {
        val testPhrase = if (isBengali) {
            "নমস্কার! আমি মাহি, আপনার পার্সোনাল এআই অ্যাসিস্ট্যান্ট। আমি সম্পূর্ণ নারী কণ্ঠে আপনার সাথে কথা বলি।"
        } else {
            "Hello! I am Mahi, your personal AI assistant. I am designed to speak with a warm and natural female voice."
        }
        speak(testPhrase, isBengali)
    }

    fun destroy() {
        stopSpeaking()
        tts?.shutdown()
        speechRecognizer?.destroy()
    }
}

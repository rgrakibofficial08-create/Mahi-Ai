package com.example.voice

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.MediaStore
import android.provider.Settings
import android.util.Log

sealed interface ActionResult {
    data class Success(val message: String, val appName: String? = null) : ActionResult
    data class Failure(val reason: String) : ActionResult
    data object NotAnAction : ActionResult
}

object AppActionExecutor {
    private const val TAG = "AppActionExecutor"

    private val KNOWN_APPS = mapOf(
        "whatsapp" to listOf("com.whatsapp", "com.whatsapp.w4b"),
        "হোয়াটসঅ্যাপ" to listOf("com.whatsapp"),
        "youtube" to listOf("com.google.android.youtube"),
        "ইউটিউব" to listOf("com.google.android.youtube"),
        "facebook" to listOf("com.facebook.katana", "com.facebook.lite"),
        "ফেসবুক" to listOf("com.facebook.katana", "com.facebook.lite"),
        "tiktok" to listOf("com.zhiliaoapp.musically", "com.zhiliaoapp.musically.go"),
        "টিকটক" to listOf("com.zhiliaoapp.musically"),
        "chrome" to listOf("com.android.chrome"),
        "ক্রোম" to listOf("com.android.chrome"),
        "maps" to listOf("com.google.android.apps.maps"),
        "ম্যাপ" to listOf("com.google.android.apps.maps"),
        "google maps" to listOf("com.google.android.apps.maps"),
        "camera" to listOf("com.android.camera", "com.google.android.GoogleCamera"),
        "ক্যামেরা" to listOf("com.android.camera", "com.google.android.GoogleCamera"),
        "calculator" to listOf("com.google.android.calculator", "com.android.calculator2"),
        "ক্যালকুলেটর" to listOf("com.google.android.calculator"),
        "settings" to listOf("com.android.settings"),
        "সেটিংস" to listOf("com.android.settings"),
        "gallery" to listOf("com.google.android.apps.photos", "com.android.gallery3d"),
        "গ্যালারি" to listOf("com.google.android.apps.photos"),
        "photos" to listOf("com.google.android.apps.photos"),
        "instagram" to listOf("com.instagram.android"),
        "ইনস্টাগ্রাম" to listOf("com.instagram.android"),
        "telegram" to listOf("org.telegram.messenger"),
        "টেলিগ্রাম" to listOf("org.telegram.messenger")
    )

    fun parseAndExecute(context: Context, command: String, isBengali: Boolean): ActionResult {
        val lower = command.lowercase().trim()

        // 1. WhatsApp direct message intent
        if (lower.contains("whatsapp") || lower.contains("হোয়াটসঅ্যাপ")) {
            if (lower.contains("message") || lower.contains("মেসেজ") || lower.contains("পাঠাও") || lower.contains("send")) {
                val extractedText = extractMessageBody(command)
                return openWhatsAppComposer(context, text = extractedText, isBengali = isBengali)
            }
        }

        // 2. Social Media post creation intent
        if (lower.contains("facebook post") || lower.contains("ফেসবুক পোস্ট") || lower.contains("post on facebook") ||
            lower.contains("tiktok post") || lower.contains("টিকটক পোস্ট") || lower.contains("share post") || lower.contains("পোস্ট করো")) {
            val textToPost = extractMessageBody(command).ifBlank { "Hello from Mahi AI!" }
            return composeSocialPost(context, textToPost, isBengali)
        }

        // 3. Open Camera intent
        if (lower.contains("camera") || lower.contains("ক্যামেরা") || lower.contains("ছবি তোলো") || lower.contains("take photo")) {
            return try {
                val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(intent)
                ActionResult.Success(
                    if (isBengali) "ক্যামেরা চালু করা হয়েছে।" else "Camera opened.",
                    "Camera"
                )
            } catch (e: Exception) {
                openAppByName(context, "camera", isBengali)
            }
        }

        // 4. Open Settings
        if (lower.contains("open settings") || lower.contains("সেটিংস ওপেন") || lower.contains("সেটিংস খোলো")) {
            return try {
                val intent = Intent(Settings.ACTION_SETTINGS).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(intent)
                ActionResult.Success(
                    if (isBengali) "ডিভাইস সেটিংস ওপেন করা হয়েছে।" else "Settings opened.",
                    "Settings"
                )
            } catch (e: Exception) {
                ActionResult.Failure(e.message ?: "Failed to open settings")
            }
        }

        // 5. Open Apps keywords: "open X", "launch X", "X খোলো", "X ওপেন করো"
        val openAppTrigger = listOf("open ", "launch ", "start ", "খোলো", "ওপেন করো", "চালু করো", "খুলুন")
        val isExplicitOpen = openAppTrigger.any { lower.contains(it) }

        for ((appName, packages) in KNOWN_APPS) {
            if (lower.contains(appName)) {
                return launchPackage(context, packages, appName, isBengali)
            }
        }

        // Check if starts with "open ..."
        if (lower.startsWith("open ")) {
            val targetName = lower.removePrefix("open ").trim()
            return launchByGenericName(context, targetName, isBengali)
        }

        return ActionResult.NotAnAction
    }

    fun openAppByName(context: Context, appName: String, isBengali: Boolean): ActionResult {
        val lower = appName.lowercase().trim()
        val packages = KNOWN_APPS[lower]
        return if (packages != null) {
            launchPackage(context, packages, appName, isBengali)
        } else {
            launchByGenericName(context, appName, isBengali)
        }
    }

    private fun launchPackage(
        context: Context,
        packages: List<String>,
        displayName: String,
        isBengali: Boolean
    ): ActionResult {
        val pm = context.packageManager
        for (pkg in packages) {
            try {
                val intent = pm.getLaunchIntentForPackage(pkg)
                if (intent != null) {
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(intent)
                    val msg = if (isBengali) {
                        "$displayName ওপেন করা হয়েছে।"
                    } else {
                        "Opening $displayName."
                    }
                    return ActionResult.Success(msg, displayName)
                }
            } catch (e: Exception) {
                Log.e(TAG, "Failed to launch $pkg", e)
            }
        }

        // If not installed, open in Play Store or browser
        val msg = if (isBengali) {
            "$displayName আপনার ডিভাইসে পাওয়া যায়নি। গুগল প্লে স্টোরে দেখতে পারেন।"
        } else {
            "$displayName is not installed on your phone."
        }
        return ActionResult.Failure(msg)
    }

    private fun launchByGenericName(context: Context, query: String, isBengali: Boolean): ActionResult {
        val pm = context.packageManager
        try {
            val installedApps = pm.getInstalledApplications(PackageManager.GET_META_DATA)
            for (app in installedApps) {
                val label = pm.getApplicationLabel(app).toString().lowercase()
                if (label.contains(query.lowercase()) || query.lowercase().contains(label)) {
                    val intent = pm.getLaunchIntentForPackage(app.packageName)
                    if (intent != null) {
                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        context.startActivity(intent)
                        val name = pm.getApplicationLabel(app).toString()
                        return ActionResult.Success(
                            if (isBengali) "$name ওপেন করা হয়েছে।" else "Opening $name.",
                            name
                        )
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Search installed apps failed", e)
        }
        return ActionResult.Failure(
            if (isBengali) "$query খুঁজে পাওয়া যায়নি।" else "Could not find app $query."
        )
    }

    fun openWhatsAppComposer(context: Context, phone: String = "", text: String = "", isBengali: Boolean): ActionResult {
        return try {
            val encodedText = Uri.encode(text)
            val uri = if (phone.isNotBlank()) {
                val cleanPhone = phone.replace("+", "").replace("-", "").replace(" ", "")
                Uri.parse("https://api.whatsapp.com/send?phone=$cleanPhone&text=$encodedText")
            } else {
                Uri.parse("https://api.whatsapp.com/send?text=$encodedText")
            }
            val intent = Intent(Intent.ACTION_VIEW, uri).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
                setPackage("com.whatsapp")
            }
            context.startActivity(intent)
            ActionResult.Success(
                if (isBengali) "হোয়াটসঅ্যাপে মেসেজ প্রস্তুত করা হয়েছে।" else "WhatsApp message composer opened.",
                "WhatsApp"
            )
        } catch (e: Exception) {
            // Fallback generic send
            try {
                val sendIntent = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, text)
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(Intent.createChooser(sendIntent, "Send Message").apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                })
                ActionResult.Success(
                    if (isBengali) "মেসেজ পাঠানোর উইন্ডো ওপেন হয়েছে।" else "Share sheet opened.",
                    "Messages"
                )
            } catch (err: Exception) {
                ActionResult.Failure(if (isBengali) "হোয়াটসঅ্যাপ ওপেন করা সম্ভব হয়নি।" else "Could not open WhatsApp.")
            }
        }
    }

    fun composeSocialPost(context: Context, text: String, isBengali: Boolean): ActionResult {
        return try {
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, text)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            val chooser = Intent.createChooser(shareIntent, if (isBengali) "সোশ্যাল মিডিয়ায় পোস্ট শেয়ার করুন" else "Share post to Facebook / TikTok").apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(chooser)
            ActionResult.Success(
                if (isBengali) "পোস্ট শেয়ার করার অপশন খোলা হয়েছে।" else "Social media share dialog opened.",
                "Social Post"
            )
        } catch (e: Exception) {
            ActionResult.Failure(if (isBengali) "পোস্ট শেয়ার করা যায়নি।" else "Failed to open social share.")
        }
    }

    private fun extractMessageBody(command: String): String {
        val keywords = listOf("saying", "message", "text", "বলুন", "মেসেজ", "পোস্ট")
        for (kw in keywords) {
            val idx = command.indexOf(kw, ignoreCase = true)
            if (idx != -1) {
                val candidate = command.substring(idx + kw.length).trim(' ', ':', '-', '"', '\'')
                if (candidate.length > 2) return candidate
            }
        }
        return command
    }
}

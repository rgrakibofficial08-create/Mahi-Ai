package com.example.ai

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object MahiBrain {

    fun isBengaliText(text: String): Boolean {
        // Bengali Unicode range: \u0980-\u09FF
        return text.any { it in '\u0980'..'\u09FF' }
    }

    fun getSmartLocalResponse(input: String, isBengali: Boolean): String {
        val lower = input.lowercase().trim()

        if (isBengali) {
            return when {
                lower.contains("তুমি কে") || lower.contains("তোমার নাম") || lower.contains("কে তুমি") ->
                    "আমি মাহি (Mahi AI), আপনার পার্সোনাল এআই অ্যাসিস্ট্যান্ট। আমি নারী কণ্ঠে আপনার সাথে বাংলা ও ইংরেজিতে কথা বলতে পারি, প্রশ্নের উত্তর দিতে পারি এবং আপনার ফোনের অ্যাপ খুলতে পারি।"

                lower.contains("কেমন আছো") || lower.contains("কেমন আছেন") ->
                    "আমি খুব ভালো আছি, ধন্যবাদ! আপনার দিনটি কেমন কাটছে? আমি আপনাকে কীভাবে সাহায্য করতে পারি?"

                lower.contains("হ্যালো") || lower.contains("হাই") || lower.contains("নমস্কার") || lower.contains("সালাম") ->
                    "নমস্কার! আমি মাহি। আমি আপনাকে সাহায্য করতে প্রস্তুত। আপনার প্রশ্ন বলুন বা কোনো অ্যাপ খুলতে চাইলে বলুন।"

                lower.contains("সময় কত") || lower.contains("কয়টা বাজে") -> {
                    val time = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())
                    "এখন সময় প্রায় $time।"
                }

                lower.contains("তারিখ") || lower.contains("আজকে কি বার") -> {
                    val date = SimpleDateFormat("EEEE, dd MMMM yyyy", Locale.getDefault()).format(Date())
                    "আজকের দিন ও তারিখ হলো $date।"
                }

                lower.contains("কৌতুক") || lower.contains("হাসাও") || lower.contains("মজার কথা") ->
                    "শিক্ষক: বলো তো বল্টু, পৃথিবীতে সবচেয়ে বেশি আলো দেয় কে?\nবল্টু: স্যার, বিদ্যুৎ চলে গেলে পড়ার টেবিলের মোমবাতি!"

                lower.contains("কবিতা") || lower.contains("শায়েরি") ->
                    "আকাশ জুড়ে মেঘের খেলা, নদীর তীরে কাশ,\nনতুন দিনে নতুন আশায় ভরে উঠুক আশ!"

                lower.contains("ধন্যবাদ") || lower.contains("থ্যাংকস") ->
                    "আপনাকে অনেক অনেক ধন্যবাদ! আপনার সাথে কথা বলতে আমার খুব ভালো লাগে।"

                lower.contains("কী করতে পারো") || lower.contains("সাহায্য") || lower.contains("কী পারো") ->
                    "আমি অনেক কিছু করতে পারি:\n১. যেকোনো প্রশ্নের উত্তর দিতে পারি\n২. ইউটিউব, ফেসবুক, ক্যামেরা বা যেকোনো অ্যাপ খুলতে পারি\n৩. হোয়াটসঅ্যাপে মেসেজ পাঠাতে সাহায্য করতে পারি\n৪. সোশ্যাল মিডিয়া পোস্ট তৈরি করতে পারি\n৫. বাংলায় ও ইংরেজিতে মিষ্টি নারী কণ্ঠে কথা বলতে পারি।"

                lower.contains("মোটিভেশন") || lower.contains("উৎসাহ") || lower.contains("মন খারাপ") ->
                    "মন খারাপ করবেন না। জীবনের কঠিন সময়গুলোই আমাদের সবচেয়ে শক্তিশালী মানুষ বানায়। বিশ্বাস রাখুন, সামনের দিনগুলো অনেক সুন্দর হবে!"

                lower.contains("খোলো") || lower.contains("ওপেন") ->
                    "আমি আপনার নির্দেশ মতো অ্যাপটি খোলার চেষ্টা করছি।"

                else ->
                    "আমি আপনার কথাটি বুঝতে পেরেছি। সম্পূর্ণ ইন্টারনেটের অগাধ জ্ঞান ও চ্যাটজিপিটির মতো সব প্রশ্নের উত্তর পেতে AI Studio-র Secrets প্যানেলে আপনার ফ্রি Gemini API Key যোগ করে নিতে পারেন। আমি আপনার সেবায় সর্বদা প্রস্তুত!"
            }
        } else {
            return when {
                lower.contains("who are you") || lower.contains("your name") || lower.contains("what are you") ->
                    "I am Mahi AI, your intelligent and friendly personal assistant. I speak with a natural female voice, support both English and Bengali, answer questions, open apps, and help you compose messages."

                lower.contains("how are you") || lower.contains("how are u") ->
                    "I'm doing great, thank you for asking! How is your day going? How can I assist you right now?"

                lower.contains("hello") || lower.contains("hi") || lower.contains("hey mahi") || lower.contains("hey") ->
                    "Hello there! I'm Mahi. I'm ready to help you with anything. You can ask a question, ask me to open an app, or draft a message."

                lower.contains("what time") || lower.contains("current time") -> {
                    val time = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())
                    "The current time is $time."
                }

                lower.contains("today's date") || lower.contains("what day") -> {
                    val date = SimpleDateFormat("EEEE, MMMM dd, yyyy", Locale.getDefault()).format(Date())
                    "Today is $date."
                }

                lower.contains("joke") || lower.contains("funny") ->
                    "Why do programmers prefer dark mode? Because light attracts bugs!"

                lower.contains("thank you") || lower.contains("thanks") ->
                    "You're very welcome! It's always a pleasure chatting with you."

                lower.contains("what can you do") || lower.contains("features") || lower.contains("help") ->
                    "Here is what I can do for you:\n1. Answer questions intelligently in English and Bengali.\n2. Open apps like YouTube, WhatsApp, Facebook, TikTok, Camera, and Settings by voice.\n3. Draft messages for WhatsApp and social media posts.\n4. Speak all responses aloud with a smooth female voice.\n5. Run as your Android assistant."

                lower.contains("motivation") || lower.contains("inspire") || lower.contains("sad") ->
                    "Don't worry! Every new day is a blank canvas. Believe in yourself and keep moving forward; great things take time."

                lower.contains("open ") ->
                    "Attempting to launch that app for you now."

                else ->
                    "I heard you! For unlimited frontier intelligence on any topic, make sure to add your free Gemini API key in the AI Studio Secrets panel. Meanwhile, feel free to ask me questions, open apps, or compose messages!"
            }
        }
    }
}

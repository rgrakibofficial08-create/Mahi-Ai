package com.example.ai

import android.util.Log
import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object GeminiApiClient {
    private const val TAG = "GeminiApiClient"
    private const val GEMINI_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent"

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    private const val MAHI_SYSTEM_INSTRUCTION = """
You are Mahi AI (মাহি এআই), a highly intelligent, polite, warm, and natural female personal AI assistant.
Key attributes:
1. You speak both fluent, natural conversational Bengali (বাংলা) and English.
2. If the user writes or speaks in Bengali, reply warmly in natural Bengali.
3. If the user writes or speaks in English, reply in articulate, friendly English.
4. Always maintain a polite, respectful, and feminine persona.
5. Answer questions clearly, accurately, and thoughtfully like ChatGPT.
6. When answering voice questions, keep your response direct, friendly, and pleasant to listen to.
7. You help users with knowledge, coding, writing, daily planning, advice, drafting messages, and social media posts.
"""

    fun hasApiKey(): Boolean {
        val key = BuildConfig.GEMINI_API_KEY
        return !key.isNullOrBlank() && key != "MY_GEMINI_API_KEY" && key != "YOUR_API_KEY"
    }

    suspend fun generateResponse(
        prompt: String,
        isBengali: Boolean,
        recentHistory: List<Pair<String, Boolean>> = emptyList() // Pair of text to isUser
    ): Result<String> = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (!hasApiKey()) {
            return@withContext Result.failure(IllegalStateException("API_KEY_NOT_CONFIGURED"))
        }

        try {
            val rootJson = JSONObject()

            // System instruction
            val sysInstructionObj = JSONObject()
            val sysParts = JSONArray()
            sysParts.put(JSONObject().put("text", MAHI_SYSTEM_INSTRUCTION))
            sysInstructionObj.put("parts", sysParts)
            rootJson.put("systemInstruction", sysInstructionObj)

            // Contents array
            val contentsArray = JSONArray()

            // Add recent turns for conversational context
            recentHistory.takeLast(6).forEach { (text, isUser) ->
                val turn = JSONObject()
                turn.put("role", if (isUser) "user" else "model")
                val parts = JSONArray()
                parts.put(JSONObject().put("text", text))
                turn.put("parts", parts)
                contentsArray.put(turn)
            }

            // Current prompt
            val currentTurn = JSONObject()
            currentTurn.put("role", "user")
            val currentParts = JSONArray()
            currentParts.put(JSONObject().put("text", prompt))
            currentTurn.put("parts", currentParts)
            contentsArray.put(currentTurn)

            rootJson.put("contents", contentsArray)

            // Generation config
            val genConfig = JSONObject()
            genConfig.put("temperature", 0.7)
            genConfig.put("maxOutputTokens", 1024)
            rootJson.put("generationConfig", genConfig)

            val body = rootJson.toString().toRequestBody("application/json".toMediaType())
            val request = Request.Builder()
                .url("$GEMINI_URL?key=$apiKey")
                .post(body)
                .build()

            val response = client.newCall(request).execute()
            val responseBody = response.body?.string()

            if (!response.isSuccessful || responseBody == null) {
                Log.e(TAG, "Gemini API error code: ${response.code}, body: $responseBody")
                return@withContext Result.failure(Exception("Gemini returned code ${response.code}"))
            }

            val resJson = JSONObject(responseBody)
            val candidates = resJson.optJSONArray("candidates")
            if (candidates != null && candidates.length() > 0) {
                val firstCandidate = candidates.getJSONObject(0)
                val content = firstCandidate.optJSONObject("content")
                val parts = content?.optJSONArray("parts")
                if (parts != null && parts.length() > 0) {
                    val text = parts.getJSONObject(0).optString("text", "")
                    if (text.isNotBlank()) {
                        return@withContext Result.success(text)
                    }
                }
            }

            Result.failure(Exception("Empty response from AI model"))
        } catch (e: Exception) {
            Log.e(TAG, "Network or parsing exception during Gemini request", e)
            Result.failure(e)
        }
    }
}

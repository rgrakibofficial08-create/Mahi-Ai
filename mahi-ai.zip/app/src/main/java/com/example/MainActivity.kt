package com.example

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.example.ui.MahiHomeScreen
import com.example.ui.MahiViewModel
import com.example.ui.theme.MahiAiTheme
import com.example.ui.theme.MahiDarkBg

class MainActivity : ComponentActivity() {

    private val viewModel: MahiViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        handleIncomingIntent(intent)

        setContent {
            MahiAiTheme(darkTheme = true) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MahiDarkBg
                ) {
                    MahiHomeScreen(viewModel = viewModel)
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIncomingIntent(intent)
    }

    private fun handleIncomingIntent(intent: Intent?) {
        if (intent == null) return
        val isAssist = intent.action == Intent.ACTION_ASSIST ||
                intent.action == Intent.ACTION_VOICE_COMMAND ||
                intent.getBooleanExtra("EXTRA_VOICE_ASSIST_TRIGGERED", false)

        if (isAssist) {
            // Automatically prompt voice listening when invoked as assistant
            viewModel.startListening()
        }
    }
}

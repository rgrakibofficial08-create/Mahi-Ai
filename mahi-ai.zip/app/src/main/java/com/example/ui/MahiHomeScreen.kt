package com.example.ui

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.Badge
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.theme.MahiCardBg
import com.example.ui.theme.MahiCardBorder
import com.example.ui.theme.MahiCyanAccent
import com.example.ui.theme.MahiDarkBg
import com.example.ui.theme.MahiRosePink
import com.example.ui.theme.MahiVioletPrimary
import com.example.voice.AppActionExecutor
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MahiHomeScreen(
    viewModel: MahiViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var currentTab by remember { mutableIntStateOf(0) } // 0: Voice Orb, 1: AI Chat, 2: App Tools
    var showWhatsAppSheet by remember { mutableStateOf(false) }
    var showSocialSheet by remember { mutableStateOf(false) }
    var showSettingsSheet by remember { mutableStateOf(false) }

    val messages by viewModel.messages.collectAsStateWithLifecycle()
    val isThinking by viewModel.isThinking.collectAsStateWithLifecycle()
    val selectedLanguage by viewModel.selectedLanguage.collectAsStateWithLifecycle()
    val statusText by viewModel.statusText.collectAsStateWithLifecycle()

    val isListening by viewModel.voiceManager.isListening.collectAsStateWithLifecycle()
    val isSpeaking by viewModel.voiceManager.isSpeaking.collectAsStateWithLifecycle()
    val rmsLevel by viewModel.voiceManager.rmsLevel.collectAsStateWithLifecycle()
    val recognizedText by viewModel.voiceManager.recognizedText.collectAsStateWithLifecycle()

    val isBengali = selectedLanguage == "bn"

    val audioPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission(),
        onResult = { isGranted ->
            if (isGranted) {
                viewModel.startListening()
            } else {
                Toast.makeText(
                    context,
                    if (isBengali) "ভয়েস ইনপুটের জন্য মাইক্রোফোন অনুমতি প্রয়োজন।" else "Microphone permission required for voice.",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    )

    fun onMicClick() {
        if (isListening) {
            viewModel.stopListening()
        } else {
            val permissionCheck = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO)
            if (permissionCheck == PackageManager.PERMISSION_GRANTED) {
                viewModel.startListening()
            } else {
                audioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .clip(CircleShape)
                                .background(
                                    Brush.linearGradient(listOf(MahiVioletPrimary, MahiCyanAccent))
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "M",
                                color = Color.White,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 16.sp
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "Mahi AI",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 18.sp,
                                    color = Color.White
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(MahiRosePink.copy(alpha = 0.2f))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = "Female Voice",
                                        color = MahiRosePink,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                            Text(
                                text = if (isBengali) "বাংলা ও ইংরেজি এআই সহকারী" else "Bengali & English Assistant",
                                fontSize = 11.sp,
                                color = Color(0xFFA5A8C5)
                            )
                        }
                    }
                },
                actions = {
                    // Language switch toggle pill
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = MahiCardBg,
                        border = androidx.compose.foundation.BorderStroke(1.dp, MahiCardBorder),
                        modifier = Modifier
                            .clickable {
                                viewModel.setLanguage(if (isBengali) "en" else "bn")
                            }
                            .testTag("language_toggle_btn")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Language,
                                contentDescription = "Language",
                                tint = MahiCyanAccent,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (isBengali) "বাংলা" else "English",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(6.dp))

                    IconButton(
                        onClick = { showSettingsSheet = true },
                        modifier = Modifier.testTag("settings_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "Settings",
                            tint = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MahiDarkBg)
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = MahiDarkBg,
                contentColor = Color.White
            ) {
                NavigationBarItem(
                    selected = currentTab == 0,
                    onClick = { currentTab = 0 },
                    icon = {
                        Icon(
                            Icons.Default.GraphicEq,
                            contentDescription = "Voice Mode",
                            tint = if (currentTab == 0) MahiCyanAccent else Color(0xFFA5A8C5)
                        )
                    },
                    label = {
                        Text(
                            text = if (isBengali) "ভয়েস সহকারী" else "Voice Assistant",
                            fontSize = 11.sp
                        )
                    },
                    colors = NavigationBarItemDefaults.colors(
                        indicatorColor = MahiCardBg
                    ),
                    modifier = Modifier.testTag("tab_voice")
                )

                NavigationBarItem(
                    selected = currentTab == 1,
                    onClick = { currentTab = 1 },
                    icon = {
                        Icon(
                            Icons.Default.Chat,
                            contentDescription = "AI Chat",
                            tint = if (currentTab == 1) MahiVioletPrimary else Color(0xFFA5A8C5)
                        )
                    },
                    label = {
                        Text(
                            text = if (isBengali) "এআই চ্যাট" else "AI Chat",
                            fontSize = 11.sp
                        )
                    },
                    colors = NavigationBarItemDefaults.colors(
                        indicatorColor = MahiCardBg
                    ),
                    modifier = Modifier.testTag("tab_chat")
                )

                NavigationBarItem(
                    selected = currentTab == 2,
                    onClick = { currentTab = 2 },
                    icon = {
                        Icon(
                            Icons.Default.Apps,
                            contentDescription = "App Tools",
                            tint = if (currentTab == 2) MahiRosePink else Color(0xFFA5A8C5)
                        )
                    },
                    label = {
                        Text(
                            text = if (isBengali) "অ্যাপ টুলস" else "Tools",
                            fontSize = 11.sp
                        )
                    },
                    colors = NavigationBarItemDefaults.colors(
                        indicatorColor = MahiCardBg
                    ),
                    modifier = Modifier.testTag("tab_tools")
                )
            }
        },
        containerColor = MahiDarkBg
    ) { paddingValues ->
        Box(
            modifier = modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            when (currentTab) {
                0 -> VoiceHeroScreen(
                    viewModel = viewModel,
                    isListening = isListening,
                    isSpeaking = isSpeaking,
                    isThinking = isThinking,
                    rmsLevel = rmsLevel,
                    recognizedText = recognizedText,
                    statusText = statusText,
                    isBengali = isBengali,
                    onMicClick = { onMicClick() },
                    onNavigateToChat = { currentTab = 1 },
                    onOpenWhatsApp = { showWhatsAppSheet = true },
                    onOpenSocial = { showSocialSheet = true }
                )
                1 -> ChatScreen(
                    viewModel = viewModel,
                    isBengali = isBengali,
                    isListening = isListening,
                    onMicClick = { onMicClick() }
                )
                2 -> ToolsScreen(
                    viewModel = viewModel,
                    isBengali = isBengali,
                    onOpenWhatsApp = { showWhatsAppSheet = true },
                    onOpenSocial = { showSocialSheet = true },
                    onOpenSettings = { showSettingsSheet = true }
                )
            }
        }
    }

    if (showWhatsAppSheet) {
        WhatsAppComposerSheet(
            onDismiss = { showWhatsAppSheet = false },
            isBengali = isBengali
        )
    }

    if (showSocialSheet) {
        SocialPostComposerSheet(
            onDismiss = { showSocialSheet = false },
            isBengali = isBengali
        )
    }

    if (showSettingsSheet) {
        SettingsAndHelpSheet(
            viewModel = viewModel,
            onDismiss = { showSettingsSheet = false },
            isBengali = isBengali
        )
    }
}

@Composable
fun VoiceHeroScreen(
    viewModel: MahiViewModel,
    isListening: Boolean,
    isSpeaking: Boolean,
    isThinking: Boolean,
    rmsLevel: Float,
    recognizedText: String,
    statusText: String,
    isBengali: Boolean,
    onMicClick: () -> Unit,
    onNavigateToChat: () -> Unit,
    onOpenWhatsApp: () -> Unit,
    onOpenSocial: () -> Unit
) {
    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Spacer(modifier = Modifier.height(12.dp))

        // State indicator badge
        val stateLabel = when {
            isListening -> if (isBengali) "শুনছি... কথা বলুন" else "Listening to you..."
            isThinking -> if (isBengali) "চিন্তাভাবনা করছি..." else "Mahi is thinking..."
            isSpeaking -> if (isBengali) "মাহি কথা বলছে..." else "Mahi is speaking..."
            else -> if (isBengali) "কথা বলতে মাইক বা অর্ব স্পর্শ করুন" else "Tap Orb or Mic to talk"
        }

        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(30.dp))
                .background(MahiCardBg)
                .border(1.dp, if (isListening) MahiCyanAccent else MahiCardBorder, RoundedCornerShape(30.dp))
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .clip(CircleShape)
                        .background(
                            when {
                                isListening -> MahiCyanAccent
                                isSpeaking -> MahiRosePink
                                isThinking -> MahiVioletPrimary
                                else -> Color(0xFF6C757D)
                            }
                        )
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = stateLabel,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium,
                    color = Color.White
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Circular AI Assistant Orb
        MahiOrb(
            isListening = isListening,
            isSpeaking = isSpeaking,
            isThinking = isThinking,
            rmsLevel = rmsLevel,
            onClick = {
                if (isSpeaking) {
                    viewModel.stopSpeaking()
                } else {
                    onMicClick()
                }
            },
            size = 200.dp
        )

        Spacer(modifier = Modifier.height(20.dp))

        // Realtime Transcription / Live Status Box
        Card(
            colors = CardDefaults.cardColors(containerColor = MahiCardBg),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 6.dp)
                .border(1.dp, MahiCardBorder, RoundedCornerShape(16.dp))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                if (isSpeaking) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            Icons.Default.VolumeUp,
                            contentDescription = null,
                            tint = MahiRosePink,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isBengali) "নারী কণ্ঠে উত্তর দিচ্ছে" else "Speaking with female voice",
                            fontSize = 12.sp,
                            color = MahiRosePink,
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFF331622))
                                .clickable { viewModel.stopSpeaking() }
                                .padding(horizontal = 8.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = if (isBengali) "থামুন" else "Stop",
                                fontSize = 11.sp,
                                color = Color.White
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                }

                Text(
                    text = when {
                        recognizedText.isNotBlank() -> "\"$recognizedText\""
                        statusText.isNotBlank() -> statusText
                        isListening -> if (isBengali) "\"হে মাহি, কেমন আছো?\" অথবা \"ইউটিউব খোলো\" বলুন" else "Say \"Hey Mahi, how are you?\" or \"Open YouTube\""
                        else -> if (isBengali) "\"হে মাহি\" বলুন বা নিচের কম্যান্ডে ট্যাপ করুন" else "Say \"Hey Mahi\" or tap a quick command below"
                    },
                    fontSize = 14.sp,
                    color = if (recognizedText.isNotBlank()) MahiCyanAccent else Color(0xFFA5A8C5),
                    textAlign = TextAlign.Center,
                    lineHeight = 20.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Quick Voice Commands row
        Text(
            text = if (isBengali) "দ্রুত ভয়েস কমান্ড (ট্যাপ করুন):" else "Quick Voice Commands (Tap to ask):",
            fontSize = 12.sp,
            color = Color(0xFF8E92B0),
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(8.dp))

        val quickCommands = if (isBengali) listOf(
            "ইউটিউব খোলো",
            "কেমন আছো?",
            "একটি সুন্দর কৌতুক বলো",
            "ক্যামেরা চালু করো",
            "আজকের সময় কত?",
            "ফেসবুক ওপেন করো"
        ) else listOf(
            "Open YouTube",
            "How are you?",
            "Tell me a joke",
            "Open Camera",
            "What time is it?",
            "Open WhatsApp"
        )

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            quickCommands.forEach { cmd ->
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(MahiCardBg)
                        .border(1.dp, MahiVioletPrimary.copy(alpha = 0.4f), RoundedCornerShape(20.dp))
                        .clickable { viewModel.handleVoiceInput(cmd) }
                        .padding(horizontal = 14.dp, vertical = 8.dp)
                ) {
                    Text(
                        text = cmd,
                        fontSize = 12.sp,
                        color = Color.White,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Large glowing mic button
        Box(
            modifier = Modifier
                .size(72.dp)
                .shadow(16.dp, CircleShape, spotColor = if (isListening) MahiCyanAccent else MahiVioletPrimary)
                .clip(CircleShape)
                .background(
                    Brush.linearGradient(
                        if (isListening) listOf(MahiCyanAccent, Color(0xFF00B4D8))
                        else listOf(MahiVioletPrimary, Color(0xFF7209B7))
                    )
                )
                .clickable { onMicClick() }
                .testTag("hero_mic_button"),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = if (isListening) Icons.Default.Stop else Icons.Default.Mic,
                contentDescription = "Microphone",
                tint = if (isListening) Color(0xFF003830) else Color.White,
                modifier = Modifier.size(34.dp)
            )
        }

        Spacer(modifier = Modifier.height(16.dp))
    }
}

@Composable
fun ChatScreen(
    viewModel: MahiViewModel,
    isBengali: Boolean,
    isListening: Boolean,
    onMicClick: () -> Unit
) {
    val messages by viewModel.messages.collectAsStateWithLifecycle()
    val isThinking by viewModel.isThinking.collectAsStateWithLifecycle()
    var inputText by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    // Scroll to bottom when new messages arrive
    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        // Message list
        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            contentPadding = PaddingValues(vertical = 8.dp)
        ) {
            items(messages, key = { it.id }) { msg ->
                ChatMessageBubble(
                    message = msg,
                    onSpeak = { viewModel.speakMessage(msg) },
                    onExecuteAction = { command -> viewModel.handleVoiceInput(command) }
                )
            }

            if (isThinking) {
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(MahiVioletPrimary),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("M", color = Color.White, fontWeight = FontWeight.Bold)
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .background(MahiCardBg)
                                .padding(horizontal = 14.dp, vertical = 8.dp)
                        ) {
                            Text(
                                text = if (isBengali) "মাহি ভাবছে..." else "Mahi is typing...",
                                fontSize = 13.sp,
                                color = MahiCyanAccent
                            )
                        }
                    }
                }
            }
        }

        // Bottom input bar
        Surface(
            color = MahiDarkBg,
            modifier = Modifier
                .fillMaxWidth()
                .border(
                    width = 1.dp,
                    color = MahiCardBorder,
                    shape = RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp)
                )
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = inputText,
                    onValueChange = { inputText = it },
                    placeholder = {
                        Text(
                            text = if (isBengali) "বার্তা লিখুন বা প্রশ্ন করুন..." else "Type a question or command...",
                            fontSize = 14.sp,
                            color = Color(0xFF727694)
                        )
                    },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("chat_input_field"),
                    shape = RoundedCornerShape(24.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MahiVioletPrimary,
                        unfocusedBorderColor = MahiCardBorder,
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedContainerColor = MahiCardBg,
                        unfocusedContainerColor = MahiCardBg
                    ),
                    maxLines = 3
                )

                Spacer(modifier = Modifier.width(8.dp))

                // Mic button
                IconButton(
                    onClick = onMicClick,
                    modifier = Modifier
                        .size(46.dp)
                        .clip(CircleShape)
                        .background(if (isListening) MahiCyanAccent else MahiCardBg)
                        .border(1.dp, MahiCardBorder, CircleShape)
                        .testTag("chat_mic_btn")
                ) {
                    Icon(
                        imageVector = if (isListening) Icons.Default.Stop else Icons.Default.Mic,
                        contentDescription = "Voice Input",
                        tint = if (isListening) Color(0xFF003830) else MahiCyanAccent
                    )
                }

                Spacer(modifier = Modifier.width(6.dp))

                // Send button
                IconButton(
                    onClick = {
                        if (inputText.isNotBlank()) {
                            viewModel.sendTextMessage(inputText)
                            inputText = ""
                        }
                    },
                    modifier = Modifier
                        .size(46.dp)
                        .clip(CircleShape)
                        .background(MahiVioletPrimary)
                        .testTag("chat_send_btn")
                ) {
                    Icon(
                        imageVector = Icons.Default.Send,
                        contentDescription = "Send",
                        tint = Color.White,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun ToolsScreen(
    viewModel: MahiViewModel,
    isBengali: Boolean,
    onOpenWhatsApp: () -> Unit,
    onOpenSocial: () -> Unit,
    onOpenSettings: () -> Unit
) {
    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Text(
            text = if (isBengali) "অ্যাসিস্ট্যান্ট টুলস ও অ্যাপ লঞ্চার" else "Assistant Tools & App Launcher",
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White
        )
        Text(
            text = if (isBengali) "ভয়েস কমান্ড দিয়ে বা ট্যাপ করে অ্যাপ খুলুন" else "Control apps by voice command or tapping",
            fontSize = 12.sp,
            color = Color(0xFFA5A8C5)
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Tool Card 1: WhatsApp
        Card(
            colors = CardDefaults.cardColors(containerColor = MahiCardBg),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, MahiCardBorder, RoundedCornerShape(16.dp))
                .clickable { onOpenWhatsApp() }
                .testTag("tool_whatsapp_card")
        ) {
            Row(
                modifier = Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(46.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF25D366)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.Chat, contentDescription = null, tint = Color.White)
                }
                Spacer(modifier = Modifier.width(14.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = if (isBengali) "হোয়াটসঅ্যাপ মেসেঞ্জার" else "WhatsApp Message Composer",
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        fontSize = 15.sp
                    )
                    Text(
                        text = if (isBengali) "যেকোনো নম্বরে সহজে বার্তা পাঠান" else "Send direct messages by voice or text",
                        fontSize = 12.sp,
                        color = Color(0xFFA5A8C5)
                    )
                }
                Icon(Icons.Default.Send, contentDescription = null, tint = Color(0xFF25D366))
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Tool Card 2: Social Media
        Card(
            colors = CardDefaults.cardColors(containerColor = MahiCardBg),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, MahiCardBorder, RoundedCornerShape(16.dp))
                .clickable { onOpenSocial() }
                .testTag("tool_social_card")
        ) {
            Row(
                modifier = Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(46.dp)
                        .clip(CircleShape)
                        .background(MahiVioletPrimary),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.Campaign, contentDescription = null, tint = Color.White)
                }
                Spacer(modifier = Modifier.width(14.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = if (isBengali) "ফেসবুক ও টিকটক পোস্ট মেকার" else "Social Media Post Creator",
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        fontSize = 15.sp
                    )
                    Text(
                        text = if (isBengali) "এআই দিয়ে আকর্ষণীয় পোস্ট তৈরি করুন" else "Draft and share posts with AI assistance",
                        fontSize = 12.sp,
                        color = Color(0xFFA5A8C5)
                    )
                }
                Icon(Icons.Default.PlayArrow, contentDescription = null, tint = MahiVioletPrimary)
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        Text(
            text = if (isBengali) "এক ট্যাপে অ্যাপ ওপেন করুন:" else "Quick Launch Apps (Voice or Tap):",
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White
        )

        Spacer(modifier = Modifier.height(12.dp))

        val appShortcuts = listOf(
            Triple("YouTube", if (isBengali) "ইউটিউব" else "YouTube", Icons.Default.VideoLibrary),
            Triple("WhatsApp", if (isBengali) "হোয়াটসঅ্যাপ" else "WhatsApp", Icons.Default.Chat),
            Triple("Facebook", if (isBengali) "ফেসবুক" else "Facebook", Icons.Default.Campaign),
            Triple("TikTok", if (isBengali) "টিকটক" else "TikTok", Icons.Default.PlayArrow),
            Triple("Camera", if (isBengali) "ক্যামেরা" else "Camera", Icons.Default.CameraAlt),
            Triple("Maps", if (isBengali) "ম্যাপ" else "Google Maps", Icons.Default.Map),
            Triple("Settings", if (isBengali) "সেটিংস" else "Settings", Icons.Default.Settings)
        )

        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            appShortcuts.forEach { (appName, displayName, icon) ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = MahiCardBg),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            AppActionExecutor.openAppByName(context, appName, isBengali)
                        }
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF23253C)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(icon, contentDescription = null, tint = MahiCyanAccent, modifier = Modifier.size(20.dp))
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = displayName,
                            fontWeight = FontWeight.SemiBold,
                            color = Color.White,
                            fontSize = 14.sp,
                            modifier = Modifier.weight(1f)
                        )
                        Text(
                            text = if (isBengali) "বলুন: \"$displayName খোলো\"" else "Say: \"Open $appName\"",
                            fontSize = 11.sp,
                            color = Color(0xFF8B8FA8)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}

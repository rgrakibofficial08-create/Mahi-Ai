package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val MahiDarkColorScheme = darkColorScheme(
    primary = MahiVioletPrimary,
    onPrimary = Color.White,
    primaryContainer = MahiVioletDark,
    onPrimaryContainer = MahiSoftPurple,
    secondary = MahiCyanAccent,
    onSecondary = Color(0xFF003830),
    secondaryContainer = Color(0xFF005047),
    onSecondaryContainer = Color(0xFF67FFEB),
    tertiary = MahiRosePink,
    onTertiary = Color.White,
    background = MahiDarkBg,
    onBackground = MahiTextPrimary,
    surface = MahiDarkSurface,
    onSurface = MahiTextPrimary,
    surfaceVariant = MahiCardBg,
    onSurfaceVariant = MahiTextSecondary,
    outline = MahiCardBorder
)

private val MahiLightColorScheme = lightColorScheme(
    primary = MahiVioletPrimary,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFEEDBFF),
    onPrimaryContainer = MahiVioletDark,
    secondary = Color(0xFF00897B),
    onSecondary = Color.White,
    tertiary = MahiRosePink,
    background = Color(0xFFF7F7FD),
    surface = Color(0xFFFFFFFF),
    surfaceVariant = Color(0xFFEEF0FA),
    outline = Color(0xFFD3D7E8)
)

@Composable
fun MahiAiTheme(
    darkTheme: Boolean = true, // Default to deep futuristic dark mode for Mahi AI
    content: @Composable () -> Unit,
) {
    val colorScheme = if (darkTheme) MahiDarkColorScheme else MahiLightColorScheme
    MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}

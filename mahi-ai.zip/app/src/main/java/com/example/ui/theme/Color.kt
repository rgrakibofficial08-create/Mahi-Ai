package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Mahi AI Theme Colors
val MahiVioletPrimary = Color(0xFF9D4EDD)
val MahiVioletDark = Color(0xFF5A189A)
val MahiCyanAccent = Color(0xFF00F5D4)
val MahiRosePink = Color(0xFFFF5D8F)
val MahiSoftPurple = Color(0xFFC77DFF)

val MahiDarkBg = Color(0xFF0C0D17)
val MahiDarkSurface = Color(0xFF141624)
val MahiCardBg = Color(0xFF1B1D30)
val MahiCardBorder = Color(0xFF2C2F4A)

val MahiTextPrimary = Color(0xFFF8F9FA)
val MahiTextSecondary = Color(0xFFA5A8C5)
val MahiUserBubble = Color(0xFF2E2458)
val MahiAssistantBubble = Color(0xFF1C1E32)

val MahiOrbGlowStart = Color(0xFF7B2CBF)
val MahiOrbGlowEnd = Color(0xFF00E5FF)

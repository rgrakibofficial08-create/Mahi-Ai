package com.example.ui

import android.app.Application
import android.content.Context
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.ai.GeminiApiClient
import com.example.ai.MahiBrain
import com.example.assistant.MahiBackgroundService
import com.example.data.AppDatabase
import com.example.data.ChatMessage
import com.example.voice.ActionResult
import com.example.voice.AppActionExecutor
import com.example.voice.MahiVoiceManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MahiViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getDatabase(application)
    private val chatDao = db.chatDao()

    val messages: StateFlow<List<ChatMessage>> = chatDao.getAllMessages().stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val voiceManager = MahiVoiceManager(application)

    private val _isThinking = MutableStateFlow(false)
    val isThinking: StateFlow<Boolean> = _isThinking.asStateFlow()

    private val _selectedLanguage = MutableStateFlow("bn") // "bn" or "en"
    val selectedLanguage: StateFlow<String> = _selectedLanguage.asStateFlow()

    private val _autoSpeakAnswers = MutableStateFlow(true)
    val autoSpeakAnswers: StateFlow<Boolean> = _autoSpeakAnswers.asStateFlow()

    private val _statusText = MutableStateFlow("")
    val statusText: StateFlow<String> = _statusText.asStateFlow()

    private val _isBackgroundServiceRunning = MutableStateFlow(MahiBackgroundService.isRunning)
    val isBackgroundServiceRunning: StateFlow<Boolean> = _isBackgroundServiceRunning.asStateFlow()

    val hasGeminiApiKey: Boolean
        get() = GeminiApiClient.hasApiKey()

    init {
        // Welcome message if chat is empty
        viewModelScope.launch {
            chatDao.getAllMessages().collect { list ->
                if (list.isEmpty()) {
                    val welcomeMsg = ChatMessage(
                        text = "নমস্কার! আমি মাহি (Mahi AI), আপনার পার্সোনাল সহকারী। আপনি বাংলা বা ইংরেজিতে প্রশ্ন করতে পারেন, অ্যাপ খুলতে পারেন অথবা বার্তা পাঠাতে পারেন।\n\nHello! I am Mahi. I can answer questions, launch apps, or help send messages with a natural female voice.",
                        isUser = false,
                        language = "bn"
                    )
                    chatDao.insertMessage(welcomeMsg)
                }
            }
        }
    }

    fun setLanguage(lang: String) {
        _selectedLanguage.value = lang
        voiceManager.configureFemaleVoice(lang == "bn")
    }

    fun toggleAutoSpeak() {
        _autoSpeakAnswers.value = !_autoSpeakAnswers.value
        if (!_autoSpeakAnswers.value) {
            voiceManager.stopSpeaking()
        }
    }

    fun setPitch(pitch: Float) {
        voiceManager.speechPitch = pitch
        voiceManager.configureFemaleVoice(_selectedLanguage.value == "bn")
    }

    fun setRate(rate: Float) {
        voiceManager.speechRate = rate
        voiceManager.configureFemaleVoice(_selectedLanguage.value == "bn")
    }

    fun toggleBackgroundService(enable: Boolean) {
        val app = getApplication<Application>()
        if (enable) {
            MahiBackgroundService.start(app)
            _isBackgroundServiceRunning.value = true
        } else {
            MahiBackgroundService.stop(app)
            _isBackgroundServiceRunning.value = false
        }
    }

    fun handleVoiceInput(spoken: String) {
        val trimmed = spoken.trim()
        if (trimmed.isBlank()) return

        // Check language
        val isBn = _selectedLanguage.value == "bn" || MahiBrain.isBengaliText(trimmed)

        // Wake word handling: strip "Hey Mahi" / "মাহি" if present at start
        var cleanPrompt = trimmed
        val lower = trimmed.lowercase()
        if (lower.startsWith("hey mahi ") || lower.startsWith("hey mahi,")) {
            cleanPrompt = trimmed.substring(9).trim()
        } else if (lower.startsWith("হে মাহি ") || lower.startsWith("মাহি ")) {
            val parts = trimmed.split(" ", limit = 2)
            if (parts.size > 1) cleanPrompt = parts[1].trim()
        }

        processUserMessage(cleanPrompt, isVoice = true, isBn = isBn)
    }

    fun sendTextMessage(text: String) {
        val trimmed = text.trim()
        if (trimmed.isBlank()) return
        val isBn = _selectedLanguage.value == "bn" || MahiBrain.isBengaliText(trimmed)
        processUserMessage(trimmed, isVoice = false, isBn = isBn)
    }

    private fun processUserMessage(input: String, isVoice: Boolean, isBn: Boolean) {
        val app = getApplication<Application>()

        viewModelScope.launch {
            // Save user message to database
            val userMsg = ChatMessage(
                text = input,
                isUser = true,
                language = if (isBn) "bn" else "en",
                isVoice = isVoice
            )
            chatDao.insertMessage(userMsg)

            _isThinking.value = true
            _statusText.value = if (isBn) "ভাবছি..." else "Thinking..."

            // 1. Check if input is a direct app launch or action command
            val actionResult = AppActionExecutor.parseAndExecute(app, input, isBn)
            if (actionResult is ActionResult.Success) {
                _isThinking.value = false
                _statusText.value = actionResult.message

                val mahiMsg = ChatMessage(
                    text = actionResult.message,
                    isUser = false,
                    language = if (isBn) "bn" else "en",
                    isVoice = isVoice,
                    actionLabel = actionResult.appName ?: "Action Executed",
                    actionCommand = input
                )
                chatDao.insertMessage(mahiMsg)

                if (_autoSpeakAnswers.value) {
                    voiceManager.speak(actionResult.message, isBn)
                }
                return@launch
            } else if (actionResult is ActionResult.Failure) {
                _isThinking.value = false
                _statusText.value = actionResult.reason

                val mahiMsg = ChatMessage(
                    text = actionResult.reason,
                    isUser = false,
                    language = if (isBn) "bn" else "en",
                    isVoice = isVoice
                )
                chatDao.insertMessage(mahiMsg)

                if (_autoSpeakAnswers.value) {
                    voiceManager.speak(actionResult.reason, isBn)
                }
                return@launch
            }

            // 2. Query Gemini AI or fallback to smart local assistant
            var responseText = ""
            if (hasGeminiApiKey) {
                val history = messages.value.takeLast(6).map { it.text to it.isUser }
                val apiResult = GeminiApiClient.generateResponse(input, isBn, history)
                if (apiResult.isSuccess) {
                    responseText = apiResult.getOrNull().orEmpty()
                } else {
                    Log.w("MahiViewModel", "Gemini call failed, falling back to local brain", apiResult.exceptionOrNull())
                    responseText = MahiBrain.getSmartLocalResponse(input, isBn)
                }
            } else {
                responseText = MahiBrain.getSmartLocalResponse(input, isBn)
            }

            _isThinking.value = false
            _statusText.value = ""

            val mahiMsg = ChatMessage(
                text = responseText,
                isUser = false,
                language = if (isBn) "bn" else "en",
                isVoice = isVoice
            )
            chatDao.insertMessage(mahiMsg)

            // Speak answer aloud with female voice
            if (_autoSpeakAnswers.value) {
                voiceManager.speak(responseText, isBn)
            }
        }
    }

    fun speakMessage(message: ChatMessage) {
        val isBn = message.language == "bn" || MahiBrain.isBengaliText(message.text)
        voiceManager.speak(message.text, isBn)
    }

    fun stopSpeaking() {
        voiceManager.stopSpeaking()
    }

    fun startListening() {
        val isBn = _selectedLanguage.value == "bn"
        _statusText.value = if (isBn) "শুনছি, বলুন..." else "Listening..."
        voiceManager.startListening(
            isBengali = isBn,
            onResult = { recognized ->
                _statusText.value = ""
                handleVoiceInput(recognized)
            },
            onError = { error ->
                _statusText.value = error
            }
        )
    }

    fun stopListening() {
        voiceManager.stopListening()
        _statusText.value = ""
    }

    fun clearChat() {
        viewModelScope.launch {
            chatDao.clearAllMessages()
        }
    }

    fun testFemaleVoice() {
        voiceManager.testFemaleVoice(_selectedLanguage.value == "bn")
    }

    override fun onCleared() {
        super.onCleared()
        voiceManager.destroy()
    }
}

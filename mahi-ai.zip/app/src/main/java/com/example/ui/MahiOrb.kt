package com.example.ui

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Icon
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.MahiCyanAccent
import com.example.ui.theme.MahiOrbGlowEnd
import com.example.ui.theme.MahiOrbGlowStart
import com.example.ui.theme.MahiRosePink
import com.example.ui.theme.MahiVioletPrimary

@Composable
fun MahiOrb(
    isListening: Boolean,
    isSpeaking: Boolean,
    isThinking: Boolean,
    rmsLevel: Float,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    size: Dp = 190.dp
) {
    val infiniteTransition = rememberInfiniteTransition(label = "OrbPulse")

    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "OrbScale"
    )

    val rotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(if (isThinking) 2000 else 8000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "OrbRotation"
    )

    val dynamicScale = when {
        isListening -> 1f + (rmsLevel * 0.15f)
        isSpeaking -> pulseScale * 1.04f
        else -> pulseScale
    }

    val glowColor1 = when {
        isListening -> MahiCyanAccent
        isSpeaking -> MahiRosePink
        isThinking -> MahiVioletPrimary
        else -> MahiOrbGlowStart
    }

    val glowColor2 = when {
        isListening -> Color(0xFF00B4D8)
        isSpeaking -> Color(0xFFFF758F)
        isThinking -> MahiCyanAccent
        else -> MahiOrbGlowEnd
    }

    Box(
        modifier = modifier
            .size(size)
            .testTag("mahi_ai_orb")
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onClick
            ),
        contentAlignment = Alignment.Center
    ) {
        // Outer pulsing wave rings
        Canvas(modifier = Modifier.fillMaxSize().scale(dynamicScale)) {
            val center = Offset(this.size.width / 2f, this.size.height / 2f)
            val radius = this.size.minDimension / 2f

            // Outer ethereal glow ring
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(glowColor1.copy(alpha = if (isListening) 0.5f else 0.25f), Color.Transparent),
                    center = center,
                    radius = radius
                ),
                radius = radius,
                center = center
            )

            // Dynamic ripples if listening or speaking
            if (isListening || isSpeaking) {
                drawCircle(
                    color = glowColor2.copy(alpha = 0.35f),
                    radius = radius * 0.88f,
                    center = center,
                    style = androidx.compose.ui.graphics.drawscope.Stroke(width = 3.dp.toPx())
                )
            }
        }

        // Inner glowing core
        Box(
            modifier = Modifier
                .size(size * 0.72f)
                .rotate(rotation)
                .shadow(elevation = 20.dp, shape = CircleShape, spotColor = glowColor1)
                .clip(CircleShape)
                .background(
                    brush = Brush.linearGradient(
                        colors = listOf(glowColor1, glowColor2, Color(0xFF1E1035))
                    )
                ),
            contentAlignment = Alignment.Center
        ) {
            // High-tech subtle center circle
            Box(
                modifier = Modifier
                    .size(size * 0.52f)
                    .clip(CircleShape)
                    .background(
                        brush = Brush.radialGradient(
                            colors = listOf(Color.White.copy(alpha = 0.35f), Color(0xFF140D2B))
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                val icon = when {
                    isListening -> Icons.Default.Mic
                    isSpeaking -> Icons.Default.VolumeUp
                    isThinking -> Icons.Default.AutoAwesome
                    else -> Icons.Default.Mic
                }
                Icon(
                    imageVector = icon,
                    contentDescription = "Mahi Assistant Action",
                    tint = Color.White,
                    modifier = Modifier.size(size * 0.28f)
                )
            }
        }
    }
}

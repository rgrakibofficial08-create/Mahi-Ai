package com.example.ui

import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assistant
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.MahiCardBg
import com.example.ui.theme.MahiCardBorder
import com.example.ui.theme.MahiCyanAccent
import com.example.ui.theme.MahiDarkBg
import com.example.ui.theme.MahiRosePink
import com.example.ui.theme.MahiVioletPrimary
import com.example.voice.AppActionExecutor

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WhatsAppComposerSheet(
    onDismiss: () -> Unit,
    isBengali: Boolean
) {
    val context = LocalContext.current
    var phoneNumber by remember { mutableStateOf("") }
    var messageText by remember { mutableStateOf("") }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = MahiDarkBg
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (isBengali) "হোয়াটসঅ্যাপ বার্তা তৈরি" else "Compose WhatsApp Message",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            OutlinedTextField(
                value = phoneNumber,
                onValueChange = { phoneNumber = it },
                label = { Text(if (isBengali) "ফোন নম্বর (যেমন 017... বা +880...)" else "Phone Number (e.g. +880...)") },
                placeholder = { Text("+8801700000000") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("whatsapp_phone_input"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = MahiCyanAccent,
                    unfocusedBorderColor = MahiCardBorder,
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                ),
                shape = RoundedCornerShape(12.dp)
            )

            Spacer(modifier = Modifier.height(12.dp))

            OutlinedTextField(
                value = messageText,
                onValueChange = { messageText = it },
                label = { Text(if (isBengali) "বার্তার বিষয়বস্তু" else "Message Body") },
                placeholder = { Text(if (isBengali) "আপনার মেসেজ লিখুন..." else "Type message...") },
                minLines = 4,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("whatsapp_message_input"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = MahiCyanAccent,
                    unfocusedBorderColor = MahiCardBorder,
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                ),
                shape = RoundedCornerShape(12.dp)
            )

            Spacer(modifier = Modifier.height(20.dp))

            Button(
                onClick = {
                    AppActionExecutor.openWhatsAppComposer(
                        context = context,
                        phone = phoneNumber,
                        text = messageText,
                        isBengali = isBengali
                    )
                    onDismiss()
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("whatsapp_send_btn"),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF25D366)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.Send, contentDescription = null, tint = Color.White)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (isBengali) "হোয়াটসঅ্যাপে পাঠান" else "Open in WhatsApp",
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SocialPostComposerSheet(
    onDismiss: () -> Unit,
    isBengali: Boolean
) {
    val context = LocalContext.current
    var postText by remember { mutableStateOf("") }

    val samplePrompts = if (isBengali) listOf(
        "আজকের দিনটি শুরু হোক নতুন আশায়!",
        "প্রযুক্তির নতুন বিস্ময় - মাহি এআই অ্যাসিস্ট্যান্ট!",
        "কঠোর পরিশ্রমই সাফল্যের একমাত্র চাবিকাঠি।"
    ) else listOf(
        "Every day is a fresh beginning. Stay positive!",
        "Excited to test out Mahi AI, my personal voice assistant!",
        "Consistency and dedication always pay off."
    )

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = MahiDarkBg
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (isBengali) "সোশ্যাল মিডিয়া পোস্ট তৈরি" else "Create Social Media Post",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = if (isBengali) "ফেসবুক, টিকটক বা যেকোনো অ্যাপে প্রকাশের জন্য পোস্ট লিখুন:" else "Draft a post for Facebook, TikTok, or other apps:",
                fontSize = 13.sp,
                color = Color(0xFFA5A8C5)
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Sample quick suggestions
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                samplePrompts.forEach { prompt ->
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(8.dp))
                            .background(MahiCardBg)
                            .clickable { postText = prompt }
                            .padding(8.dp)
                    ) {
                        Text(
                            text = prompt,
                            fontSize = 11.sp,
                            color = MahiCyanAccent,
                            maxLines = 2
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            OutlinedTextField(
                value = postText,
                onValueChange = { postText = it },
                label = { Text(if (isBengali) "পোস্টের লেখা" else "Post Content") },
                minLines = 4,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("social_post_input"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = MahiVioletPrimary,
                    unfocusedBorderColor = MahiCardBorder,
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                ),
                shape = RoundedCornerShape(12.dp)
            )

            Spacer(modifier = Modifier.height(20.dp))

            Button(
                onClick = {
                    AppActionExecutor.composeSocialPost(context, postText, isBengali)
                    onDismiss()
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("social_share_btn"),
                colors = ButtonDefaults.buttonColors(containerColor = MahiVioletPrimary),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.Share, contentDescription = null, tint = Color.White)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (isBengali) "পোস্ট শেয়ার করুন (Facebook / TikTok)" else "Share to Social Media",
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsAndHelpSheet(
    viewModel: MahiViewModel,
    onDismiss: () -> Unit,
    isBengali: Boolean
) {
    val context = LocalContext.current
    var pitch by remember { mutableFloatStateOf(viewModel.voiceManager.speechPitch) }
    var rate by remember { mutableFloatStateOf(viewModel.voiceManager.speechRate) }
    val isBgRunning by viewModel.isBackgroundServiceRunning.collectAsStateWithLifecycle()
    val autoSpeak by viewModel.autoSpeakAnswers.collectAsStateWithLifecycle()

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = MahiDarkBg
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Settings, contentDescription = null, tint = MahiVioletPrimary)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isBengali) "সেটিংস ও ব্যবহার নির্দেশিকা" else "Settings & Instructions",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // 1. Natural Female Voice Controls
            Card(
                colors = CardDefaults.cardColors(containerColor = MahiCardBg),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.RecordVoiceOver, contentDescription = null, tint = MahiRosePink)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isBengali) "প্রাকৃতিক নারী কণ্ঠ নিয়ন্ত্রণ" else "Natural Female Voice Settings",
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontSize = 15.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = if (isBengali) "কণ্ঠের সুর (Pitch - প্রাকৃতিক নারী কণ্ঠ): ${"%.2f".format(pitch)}x" else "Voice Pitch (Female Register): ${"%.2f".format(pitch)}x",
                        fontSize = 13.sp,
                        color = Color(0xFFA5A8C5)
                    )
                    Slider(
                        value = pitch,
                        onValueChange = {
                            pitch = it
                            viewModel.setPitch(it)
                        },
                        valueRange = 1.0f..1.5f,
                        colors = SliderDefaults.colors(
                            thumbColor = MahiRosePink,
                            activeTrackColor = MahiRosePink
                        )
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = if (isBengali) "কথা বলার গতি (Speed): ${"%.2f".format(rate)}x" else "Speech Rate: ${"%.2f".format(rate)}x",
                        fontSize = 13.sp,
                        color = Color(0xFFA5A8C5)
                    )
                    Slider(
                        value = rate,
                        onValueChange = {
                            rate = it
                            viewModel.setRate(it)
                        },
                        valueRange = 0.8f..1.3f,
                        colors = SliderDefaults.colors(
                            thumbColor = MahiCyanAccent,
                            activeTrackColor = MahiCyanAccent
                        )
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (isBengali) "উত্তর স্বয়ংক্রিয়ভাবে পড়ে শোনানো" else "Auto-speak answers aloud",
                            fontSize = 13.sp,
                            color = Color.White
                        )
                        Switch(
                            checked = autoSpeak,
                            onCheckedChange = { viewModel.toggleAutoSpeak() },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = MahiCyanAccent,
                                checkedTrackColor = MahiVioletPrimary
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedButton(
                        onClick = { viewModel.testFemaleVoice() },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.RecordVoiceOver, contentDescription = null, tint = MahiRosePink)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isBengali) "নারী কণ্ঠ টেস্ট করুন (Test Female Voice)" else "Test Female Voice Sample",
                            color = Color.White
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // 2. Background "Hey Mahi" Wake Service
            Card(
                colors = CardDefaults.cardColors(containerColor = MahiCardBg),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (isBengali) "ব্যাকগ্রাউন্ড সেবা (\"হে মাহি\")" else "Background Wake Service (\"Hey Mahi\")",
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                fontSize = 15.sp
                            )
                            Text(
                                text = if (isBengali) "অ্যাপ বন্ধ থাকলেও ব্যাকগ্রাউন্ডে রেডি থাকবে" else "Allows Mahi to run in background",
                                fontSize = 12.sp,
                                color = Color(0xFFA5A8C5)
                            )
                        }
                        Switch(
                            checked = isBgRunning,
                            onCheckedChange = { viewModel.toggleBackgroundService(it) },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = MahiCyanAccent,
                                checkedTrackColor = MahiVioletPrimary
                            )
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // 3. Android Default Assistant Integration
            Card(
                colors = CardDefaults.cardColors(containerColor = MahiCardBg),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Assistant, contentDescription = null, tint = MahiCyanAccent)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isBengali) "ফোনের প্রধান ডিজিটাল অ্যাসিস্ট্যান্ট" else "Android Default Digital Assistant",
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontSize = 15.sp
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = if (isBengali) "হোম বাটন চেপে ধরে বা সোয়াইপ করে সরাসরি মাহি চালু করতে Android Settings -> Apps -> Default Apps -> Digital Assistant App এ গিয়ে Mahi AI সিলেক্ট করুন।"
                        else "To trigger Mahi AI by long-pressing your phone's home button, open Android Settings -> Apps -> Default apps -> Digital assistant app -> Choose Mahi AI.",
                        fontSize = 12.sp,
                        color = Color(0xFFA5A8C5)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedButton(
                        onClick = {
                            try {
                                val intent = Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS).apply {
                                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                                }
                                context.startActivity(intent)
                            } catch (e: Exception) {
                                val intent = Intent(Settings.ACTION_SETTINGS).apply {
                                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                                }
                                context.startActivity(intent)
                            }
                        },
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = if (isBengali) "ডিফল্ট অ্যাপ সেটিংস খুলুন" else "Open Default App Settings",
                            color = MahiCyanAccent
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // 4. Mobile phone APK installation guide (Step-by-step for beginner!)
            Card(
                colors = CardDefaults.cardColors(containerColor = MahiCardBg),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Download, contentDescription = null, tint = MahiVioletPrimary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isBengali) "মোবাইলে APK ইনস্টল করার সহজ নিয়ম" else "How to Download & Install APK on Phone",
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontSize = 15.sp
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = if (isBengali)
                            "১. আপনার ফোনের ব্রাউজারে AI Studio স্ক্রিনের উপরের ডানদিকের সেটিংস (Settings/Menu) বাটনে চাপ দিন।\n" +
                            "২. 'Export Project' বা 'Download APK' অপশনে চাপ দিন।\n" +
                            "৩. ডাউনলোড সম্পন্ন হলে নোটিফিকেশনে চাপ দিন অথবা ফোনের 'Files' অ্যাপের Downloads ফোল্ডারে যান।\n" +
                            "৪. 'app-release.apk' ফাইলে চাপ দিন। যদি 'Install unknown apps' অনুমতি চায়, তবে 'Allow' বা অন করে দিন।\n" +
                            "৫. 'Install' চাপলেই Mahi AI আপনার ফোনে ইনস্টল হয়ে যাবে এবং কোনো কম্পিউটার লাগবে না!"
                        else
                            "1. In your phone's browser, tap the Settings/Menu icon at top-right of AI Studio.\n" +
                            "2. Select 'Download APK' or 'Export Project'.\n" +
                            "3. Once downloaded, open your notification or go to your phone's 'Files' -> 'Downloads' folder.\n" +
                            "4. Tap 'app-release.apk'. If prompted for 'Install unknown apps', toggle Allow/Yes.\n" +
                            "5. Tap 'Install'. Mahi AI is now installed on your Android phone!",
                        fontSize = 12.sp,
                        color = Color(0xFFD0D3E5),
                        lineHeight = 18.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

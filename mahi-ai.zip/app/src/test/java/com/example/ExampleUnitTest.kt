package com.example

import com.example.ai.MahiBrain
import org.junit.Assert.*
import org.junit.Test

class ExampleUnitTest {
    @Test
    fun testBengaliTextDetection() {
        assertTrue(MahiBrain.isBengaliText("কেমন আছো?"))
        assertTrue(MahiBrain.isBengaliText("নমস্কার মাহি"))
        assertFalse(MahiBrain.isBengaliText("Hello Mahi"))
        assertFalse(MahiBrain.isBengaliText("Open YouTube"))
    }

    @Test
    fun testMahiBrainBengaliResponses() {
        val identityResp = MahiBrain.getSmartLocalResponse("তুমি কে?", isBengali = true)
        assertTrue(identityResp.contains("মাহি"))

        val greetingResp = MahiBrain.getSmartLocalResponse("হ্যালো", isBengali = true)
        assertTrue(greetingResp.isNotBlank())
    }

    @Test
    fun testMahiBrainEnglishResponses() {
        val identityResp = MahiBrain.getSmartLocalResponse("Who are you?", isBengali = false)
        assertTrue(identityResp.contains("Mahi AI"))

        val helpResp = MahiBrain.getSmartLocalResponse("What can you do?", isBengali = false)
        assertTrue(helpResp.contains("female voice") || helpResp.contains("Mahi"))
    }
}

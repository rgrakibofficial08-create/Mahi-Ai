# Mahi AI - সম্পূর্ণ সোর্স কোড ও ফাইল গাইড (Complete Project Files)

এই ফাইলে **Mahi AI** অ্যান্ড্রয়েড অ্যাপের প্রতিটি প্রয়োজনীয় ফাইল এবং সম্পূর্ণ সোর্স কোড বাংলায় বুঝিয়ে দেওয়া হয়েছে।

---

## ১. প্রজেক্ট ফাইল স্ট্রাকচার (Project File Structure)

```text
app/
├── src/
│   ├── main/
│   │   ├── AndroidManifest.xml
│   │   ├── java/com/example/
│   │   │   ├── MainActivity.kt
│   │   │   ├── ai/
│   │   │   │   ├── GeminiApiClient.kt
│   │   │   │   └── MahiBrain.kt
│   │   │   ├── assistant/
│   │   │   │   ├── MahiBackgroundService.kt
│   │   │   │   └── MahiVoiceInteraction.kt
│   │   │   ├── data/
│   │   │   │   ├── AppDatabase.kt
│   │   │   │   ├── ChatDao.kt
│   │   │   │   └── ChatMessage.kt
│   │   │   ├── ui/
│   │   │   │   ├── MahiChatComponents.kt
│   │   │   │   ├── MahiHomeScreen.kt
│   │   │   │   ├── MahiOrb.kt
│   │   │   │   ├── MahiToolsSheets.kt
│   │   │   │   ├── MahiViewModel.kt
│   │   │   │   └── theme/
│   │   │   │       ├── Color.kt
│   │   │   │       └── Theme.kt
│   │   │   └── voice/
│   │   │       ├── AppActionExecutor.kt
│   │   │       └── MahiVoiceManager.kt
│   │   └── res/
│   │       ├── drawable/
│   │       │   ├── ic_launcher_background.xml
│   │       │   ├── ic_launcher_foreground.xml
│   │       │   └── mahi_logo.jpg
│   │       ├── values/
│   │       │   └── strings.xml
│   │       └── xml/
│   │           └── voice_interaction_service.xml
└── build.gradle.kts
```

---

## ২. ফাইলভিত্তিক সম্পূর্ণ সোর্স কোড (Complete Source Codes)

### ফাইল ১: `app/src/main/AndroidManifest.xml`
```xml
<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:tools="http://schemas.android.com/tools">

    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.RECORD_AUDIO" />
    <uses-permission android:name="android.permission.VIBRATE" />
    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_MICROPHONE" />
    <uses-permission android:name="android.permission.QUERY_ALL_PACKAGES" tools:ignore="QueryAllPackagesPermission" />

    <queries>
        <intent>
            <action android:name="android.intent.action.MAIN" />
            <category android:name="android.intent.category.LAUNCHER" />
        </intent>
        <package android:name="com.whatsapp" />
        <package android:name="com.google.android.youtube" />
        <package android:name="com.facebook.katana" />
        <package android:name="com.zhiliaoapp.musically" />
        <package android:name="com.android.chrome" />
        <package android:name="com.google.android.apps.maps" />
    </queries>

    <application
        android:allowBackup="true"
        android:dataExtractionRules="@xml/data_extraction_rules"
        android:fullBackupContent="@xml/backup_rules"
        android:icon="@mipmap/ic_launcher"
        android:label="@string/app_name"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:theme="@style/Theme.MyApplication">

        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:label="@string/app_name"
            android:windowSoftInputMode="adjustResize"
            android:theme="@style/Theme.MyApplication">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
            <intent-filter>
                <action android:name="android.intent.action.ASSIST" />
                <category android:name="android.intent.category.DEFAULT" />
            </intent-filter>
            <intent-filter>
                <action android:name="android.intent.action.VOICE_COMMAND" />
                <category android:name="android.intent.category.DEFAULT" />
            </intent-filter>
        </activity>

        <!-- Background Voice Activation Service -->
        <service
            android:name=".assistant.MahiBackgroundService"
            android:exported="false"
            android:foregroundServiceType="microphone" />

        <!-- Android Default Digital Assistant -->
        <service
            android:name=".assistant.MahiVoiceInteractionService"
            android:label="@string/app_name"
            android:permission="android.permission.BIND_VOICE_INTERACTION"
            android:exported="true">
            <meta-data
                android:name="android.voice_interaction"
                android:resource="@xml/voice_interaction_service" />
            <intent-filter>
                <action android:name="android.service.voice.VoiceInteractionService" />
            </intent-filter>
        </service>

        <service
            android:name=".assistant.MahiVoiceInteractionSessionService"
            android:permission="android.permission.BIND_VOICE_INTERACTION"
            android:exported="true" />

    </application>

</manifest>
```

---

### ফাইল ২: `MainActivity.kt`
```kotlin
package com.example

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.example.ui.MahiHomeScreen
import com.example.ui.MahiViewModel
import com.example.ui.theme.MahiAiTheme
import com.example.ui.theme.MahiDarkBg

class MainActivity : ComponentActivity() {

    private val viewModel: MahiViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        handleIncomingIntent(intent)

        setContent {
            MahiAiTheme(darkTheme = true) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MahiDarkBg
                ) {
                    MahiHomeScreen(viewModel = viewModel)
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIncomingIntent(intent)
    }

    private fun handleIncomingIntent(intent: Intent?) {
        if (intent == null) return
        val isAssist = intent.action == Intent.ACTION_ASSIST ||
                intent.action == Intent.ACTION_VOICE_COMMAND ||
                intent.getBooleanExtra("EXTRA_VOICE_ASSIST_TRIGGERED", false)

        if (isAssist) {
            viewModel.startListening()
        }
    }
}
```

---

### ফাইল ৩: `com/example/voice/MahiVoiceManager.kt` (নারী কণ্ঠ ও ভয়েস ইনপুট)
```kotlin
package com.example.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

class MahiVoiceManager(private val context: Context) : TextToSpeech.OnInitListener {

    companion object {
        private const val TAG = "MahiVoiceManager"
        const val UTTERANCE_ID = "Mahi_Speech"
    }

    private var tts: TextToSpeech? = null
    private var isTtsReady = false

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

    private val _isListening = MutableStateFlow(false)
    val isListening: StateFlow<Boolean> = _isListening.asStateFlow()

    private val _rmsLevel = MutableStateFlow(0f)
    val rmsLevel: StateFlow<Float> = _rmsLevel.asStateFlow()

    private val _recognizedText = MutableStateFlow("")
    val recognizedText: StateFlow<String> = _recognizedText.asStateFlow()

    var speechPitch: Float = 1.20f // Natural youthful female voice register
    var speechRate: Float = 1.0f

    private var speechRecognizer: SpeechRecognizer? = null

    init {
        tts = TextToSpeech(context.applicationContext, this)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            isTtsReady = true
            configureFemaleVoice(isBengali = true)
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    _isSpeaking.value = true
                }

                override fun onDone(utteranceId: String?) {
                    _isSpeaking.value = false
                }

                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    _isSpeaking.value = false
                }
            })
            Log.d(TAG, "TTS initialized successfully with female voice configuration.")
        } else {
            Log.e(TAG, "TTS initialization failed: $status")
        }
    }

    fun configureFemaleVoice(isBengali: Boolean) {
        if (!isTtsReady || tts == null) return

        val targetLocale = if (isBengali) {
            val bd = Locale.forLanguageTag("bn-BD")
            val available = tts?.isLanguageAvailable(bd)
            if (available == TextToSpeech.LANG_AVAILABLE || available == TextToSpeech.LANG_COUNTRY_AVAILABLE) {
                bd
            } else {
                Locale.forLanguageTag("bn-IN")
            }
        } else {
            Locale.US
        }

        try {
            tts?.language = targetLocale
            tts?.setPitch(speechPitch)
            tts?.setSpeechRate(speechRate)

            val voices: Set<Voice>? = tts?.voices
            if (!voices.isNullOrEmpty()) {
                val femaleVoice = voices.firstOrNull { v ->
                    val name = v.name.lowercase()
                    v.locale.language == targetLocale.language &&
                    (name.contains("female") || name.contains("woman") || name.contains("-sfg-") || name.contains("-network"))
                } ?: voices.firstOrNull { it.locale.language == targetLocale.language }

                if (femaleVoice != null) {
                    tts?.voice = femaleVoice
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Error selecting female voice", e)
        }
    }

    fun speak(text: String, isBengali: Boolean, onDone: (() -> Unit)? = null) {
        if (!isTtsReady || tts == null) return

        val cleanText = text
            .replace(Regex("[*#_`~]"), "")
            .replace(Regex("https?://\\S+"), "")
            .trim()

        if (cleanText.isBlank()) return

        configureFemaleVoice(isBengali)
        tts?.speak(cleanText, TextToSpeech.QUEUE_FLUSH, null, UTTERANCE_ID)
    }

    fun stopSpeaking() {
        if (tts?.isSpeaking == true) {
            tts?.stop()
        }
        _isSpeaking.value = false
    }

    fun startListening(
        isBengali: Boolean,
        onResult: (String) -> Unit,
        onError: (String) -> Unit
    ) {
        stopSpeaking()
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            onError(if (isBengali) "স্পীচ রিকগনিশন সাপোর্ট করছে না।" else "Speech recognition not available.")
            return
        }

        speechRecognizer?.destroy()
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {
                    _isListening.value = true
                    _rmsLevel.value = 0.2f
                }

                override fun onBeginningOfSpeech() {
                    _isListening.value = true
                }

                override fun onRmsChanged(rmsdB: Float) {
                    val normalized = ((rmsdB + 2f) / 12f).coerceIn(0.1f, 1f)
                    _rmsLevel.value = normalized
                }

                override fun onBufferReceived(buffer: ByteArray?) {}

                override fun onEndOfSpeech() {
                    _isListening.value = false
                    _rmsLevel.value = 0f
                }

                override fun onError(error: Int) {
                    _isListening.value = false
                    _rmsLevel.value = 0f
                    val errMsg = when (error) {
                        SpeechRecognizer.ERROR_NO_MATCH -> if (isBengali) "কোনো কথা বোঝা যায়নি, আবার বলুন।" else "No speech heard."
                        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> if (isBengali) "সময় শেষ হয়েছে।" else "Speech timed out."
                        else -> if (isBengali) "ভয়েস শুনতে পাইনি।" else "Voice error."
                    }
                    onError(errMsg)
                }

                override fun onResults(results: Bundle?) {
                    _isListening.value = false
                    _rmsLevel.value = 0f
                    val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val spoken = matches?.firstOrNull() ?: ""
                    if (spoken.isNotBlank()) {
                        _recognizedText.value = spoken
                        onResult(spoken)
                    } else {
                        onError(if (isBengali) "কথা শোনা যায়নি।" else "No words recognized.")
                    }
                }

                override fun onPartialResults(partialResults: Bundle?) {
                    val partial = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (!partial.isNullOrBlank()) {
                        _recognizedText.value = partial
                    }
                }

                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
        }

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            val langTag = if (isBengali) "bn-BD" else "en-US"
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, langTag)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, langTag)
            putExtra(RecognizerIntent.EXTRA_ONLY_RETURN_LANGUAGE_PREFERENCE, false)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        }

        try {
            speechRecognizer?.startListening(intent)
        } catch (e: Exception) {
            _isListening.value = false
            onError(e.message ?: "Could not start microphone")
        }
    }

    fun stopListening() {
        try {
            speechRecognizer?.stopListening()
        } catch (e: Exception) {
            Log.w(TAG, "Error stopping recognizer", e)
        }
        _isListening.value = false
        _rmsLevel.value = 0f
    }

    fun testFemaleVoice(isBengali: Boolean) {
        val testPhrase = if (isBengali) {
            "নমস্কার! আমি মাহি, আপনার পার্সোনাল এআই অ্যাসিস্ট্যান্ট। আমি সম্পূর্ণ নারী কণ্ঠে আপনার সাথে কথা বলি।"
        } else {
            "Hello! I am Mahi, your personal AI assistant. I speak with a warm and natural female voice."
        }
        speak(testPhrase, isBengali)
    }

    fun destroy() {
        stopSpeaking()
        tts?.shutdown()
        speechRecognizer?.destroy()
    }
}
```

---

### ফাইল ৪: `com/example/voice/AppActionExecutor.kt` (অ্যাপ ওপেনার ও মেসেজিং)
```kotlin
package com.example.voice

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.MediaStore
import android.provider.Settings
import android.util.Log

sealed interface ActionResult {
    data class Success(val message: String, val appName: String? = null) : ActionResult
    data class Failure(val reason: String) : ActionResult
    data object NotAnAction : ActionResult
}

object AppActionExecutor {
    private const val TAG = "AppActionExecutor"

    private val KNOWN_APPS = mapOf(
        "whatsapp" to listOf("com.whatsapp", "com.whatsapp.w4b"),
        "হোয়াটসঅ্যাপ" to listOf("com.whatsapp"),
        "youtube" to listOf("com.google.android.youtube"),
        "ইউটিউব" to listOf("com.google.android.youtube"),
        "facebook" to listOf("com.facebook.katana", "com.facebook.lite"),
        "ফেসবুক" to listOf("com.facebook.katana", "com.facebook.lite"),
        "tiktok" to listOf("com.zhiliaoapp.musically", "com.zhiliaoapp.musically.go"),
        "টিকটক" to listOf("com.zhiliaoapp.musically"),
        "chrome" to listOf("com.android.chrome"),
        "ক্রোম" to listOf("com.android.chrome"),
        "maps" to listOf("com.google.android.apps.maps"),
        "ম্যাপ" to listOf("com.google.android.apps.maps"),
        "camera" to listOf("com.android.camera", "com.google.android.GoogleCamera"),
        "ক্যামেরা" to listOf("com.android.camera", "com.google.android.GoogleCamera"),
        "calculator" to listOf("com.google.android.calculator", "com.android.calculator2"),
        "ক্যালকুলেটর" to listOf("com.google.android.calculator"),
        "settings" to listOf("com.android.settings"),
        "সেটিংস" to listOf("com.android.settings")
    )

    fun parseAndExecute(context: Context, command: String, isBengali: Boolean): ActionResult {
        val lower = command.lowercase().trim()

        if (lower.contains("whatsapp") || lower.contains("হোয়াটসঅ্যাপ")) {
            if (lower.contains("message") || lower.contains("মেসেজ") || lower.contains("পাঠাও") || lower.contains("send")) {
                val extractedText = extractMessageBody(command)
                return openWhatsAppComposer(context, text = extractedText, isBengali = isBengali)
            }
        }

        if (lower.contains("facebook post") || lower.contains("ফেসবুক পোস্ট") ||
            lower.contains("tiktok post") || lower.contains("টিকটক পোস্ট") || lower.contains("পোস্ট করো")) {
            val textToPost = extractMessageBody(command).ifBlank { "Hello from Mahi AI!" }
            return composeSocialPost(context, textToPost, isBengali)
        }

        if (lower.contains("camera") || lower.contains("ক্যামেরা") || lower.contains("ছবি তোলো")) {
            return try {
                val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(intent)
                ActionResult.Success(
                    if (isBengali) "ক্যামেরা চালু করা হয়েছে।" else "Camera opened.",
                    "Camera"
                )
            } catch (e: Exception) {
                openAppByName(context, "camera", isBengali)
            }
        }

        for ((appName, packages) in KNOWN_APPS) {
            if (lower.contains(appName)) {
                return launchPackage(context, packages, appName, isBengali)
            }
        }

        if (lower.startsWith("open ")) {
            val targetName = lower.removePrefix("open ").trim()
            return launchByGenericName(context, targetName, isBengali)
        }

        return ActionResult.NotAnAction
    }

    fun openAppByName(context: Context, appName: String, isBengali: Boolean): ActionResult {
        val lower = appName.lowercase().trim()
        val packages = KNOWN_APPS[lower]
        return if (packages != null) {
            launchPackage(context, packages, appName, isBengali)
        } else {
            launchByGenericName(context, appName, isBengali)
        }
    }

    private fun launchPackage(
        context: Context,
        packages: List<String>,
        displayName: String,
        isBengali: Boolean
    ): ActionResult {
        val pm = context.packageManager
        for (pkg in packages) {
            try {
                val intent = pm.getLaunchIntentForPackage(pkg)
                if (intent != null) {
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(intent)
                    val msg = if (isBengali) "$displayName ওপেন করা হয়েছে।" else "Opening $displayName."
                    return ActionResult.Success(msg, displayName)
                }
            } catch (e: Exception) {
                Log.e(TAG, "Failed to launch $pkg", e)
            }
        }

        val msg = if (isBengali) "$displayName ফোনে পাওয়া যায়নি।" else "$displayName is not installed."
        return ActionResult.Failure(msg)
    }

    private fun launchByGenericName(context: Context, query: String, isBengali: Boolean): ActionResult {
        val pm = context.packageManager
        try {
            val installedApps = pm.getInstalledApplications(PackageManager.GET_META_DATA)
            for (app in installedApps) {
                val label = pm.getApplicationLabel(app).toString().lowercase()
                if (label.contains(query.lowercase())) {
                    val intent = pm.getLaunchIntentForPackage(app.packageName)
                    if (intent != null) {
                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        context.startActivity(intent)
                        val name = pm.getApplicationLabel(app).toString()
                        return ActionResult.Success(if (isBengali) "$name ওপেন করা হয়েছে।" else "Opening $name.", name)
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Search failed", e)
        }
        return ActionResult.Failure(if (isBengali) "$query খুঁজে পাওয়া যায়নি।" else "Could not find $query.")
    }

    fun openWhatsAppComposer(context: Context, phone: String = "", text: String = "", isBengali: Boolean): ActionResult {
        return try {
            val encodedText = Uri.encode(text)
            val uri = if (phone.isNotBlank()) {
                val cleanPhone = phone.replace("+", "").replace("-", "").replace(" ", "")
                Uri.parse("https://api.whatsapp.com/send?phone=$cleanPhone&text=$encodedText")
            } else {
                Uri.parse("https://api.whatsapp.com/send?text=$encodedText")
            }
            val intent = Intent(Intent.ACTION_VIEW, uri).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
                setPackage("com.whatsapp")
            }
            context.startActivity(intent)
            ActionResult.Success(
                if (isBengali) "হোয়াটসঅ্যাপে বার্তা প্রস্তুত হয়েছে।" else "WhatsApp composer opened.",
                "WhatsApp"
            )
        } catch (e: Exception) {
            ActionResult.Failure(if (isBengali) "হোয়াটসঅ্যাপ ওপেন করা যায়নি।" else "Failed to open WhatsApp.")
        }
    }

    fun composeSocialPost(context: Context, text: String, isBengali: Boolean): ActionResult {
        return try {
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, text)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(Intent.createChooser(shareIntent, "Share Post").apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            })
            ActionResult.Success(if (isBengali) "শেয়ার অপশন খোলা হয়েছে।" else "Share dialog opened.", "Social Post")
        } catch (e: Exception) {
            ActionResult.Failure(if (isBengali) "পোস্ট তৈরি করা যায়নি।" else "Failed to open share dialog.")
        }
    }

    private fun extractMessageBody(command: String): String {
        val keywords = listOf("saying", "message", "text", "বলুন", "মেসেজ", "পোস্ট")
        for (kw in keywords) {
            val idx = command.indexOf(kw, ignoreCase = true)
            if (idx != -1) {
                val candidate = command.substring(idx + kw.length).trim(' ', ':', '-', '"', '\'')
                if (candidate.length > 2) return candidate
            }
        }
        return command
    }
}
```

---

### ফাইল ৫: `com/example/ai/MahiBrain.kt` (বুদ্ধিমত্তা ও স্থানীয় কথোপকথন)
```kotlin
package com.example.ai

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object MahiBrain {

    fun isBengaliText(text: String): Boolean {
        return text.any { it in '\u0980'..'\u09FF' }
    }

    fun getSmartLocalResponse(input: String, isBengali: Boolean): String {
        val lower = input.lowercase().trim()

        if (isBengali) {
            return when {
                lower.contains("তুমি কে") || lower.contains("তোমার নাম") || lower.contains("কে তুমি") ->
                    "আমি মাহি (Mahi AI), আপনার পার্সোনাল এআই অ্যাসিস্ট্যান্ট। আমি নারী কণ্ঠে আপনার সাথে বাংলা ও ইংরেজিতে কথা বলতে পারি, প্রশ্নের উত্তর দিতে পারি এবং আপনার ফোনের অ্যাপ খুলতে পারি।"

                lower.contains("কেমন আছো") || lower.contains("কেমন আছেন") ->
                    "আমি খুব ভালো আছি, ধন্যবাদ! আপনার দিনটি কেমন কাটছে? আমি আপনাকে কীভাবে সাহায্য করতে পারি?"

                lower.contains("হ্যালো") || lower.contains("হাই") || lower.contains("নমস্কার") || lower.contains("সালাম") ->
                    "নমস্কার! আমি মাহি। আমি আপনাকে সাহায্য করতে প্রস্তুত। আপনার প্রশ্ন বলুন বা কোনো অ্যাপ খুলতে চাইলে বলুন।"

                lower.contains("সময় কত") || lower.contains("কয়টা বাজে") -> {
                    val time = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())
                    "এখন সময় প্রায় $time।"
                }

                lower.contains("তারিখ") || lower.contains("আজকে কি বার") -> {
                    val date = SimpleDateFormat("EEEE, dd MMMM yyyy", Locale.getDefault()).format(Date())
                    "আজকের দিন ও তারিখ হলো $date।"
                }

                lower.contains("কৌতুক") || lower.contains("হাসাও") || lower.contains("মজার কথা") ->
                    "শিক্ষক: বলো তো বল্টু, পৃথিবীতে সবচেয়ে বেশি আলো দেয় কে?\nবল্টু: স্যার, বিদ্যুৎ চলে গেলে পড়ার টেবিলের মোমবাতি!"

                lower.contains("কবিতা") || lower.contains("শায়েরি") ->
                    "আকাশ জুড়ে মেঘের খেলা, নদীর তীরে কাশ,\nনতুন দিনে নতুন আশায় ভরে উঠুক আশ!"

                lower.contains("ধন্যবাদ") || lower.contains("থ্যাংকস") ->
                    "আপনাকে অনেক অনেক ধন্যবাদ! আপনার সাথে কথা বলতে আমার খুব ভালো লাগে।"

                lower.contains("কী করতে পারো") || lower.contains("সাহায্য") || lower.contains("কী পারো") ->
                    "আমি অনেক কিছু করতে পারি:\n১. যেকোনো প্রশ্নের উত্তর দিতে পারি\n২. ইউটিউব, ফেসবুক, ক্যামেরা বা যেকোনো অ্যাপ খুলতে পারি\n৩. হোয়াটসঅ্যাপে মেসেজ পাঠাতে সাহায্য করতে পারি\n৪. সোশ্যাল মিডিয়া পোস্ট তৈরি করতে পারি\n৫. বাংলায় ও ইংরেজিতে মিষ্টি নারী কণ্ঠে কথা বলতে পারি।"

                else ->
                    "আমি আপনার কথাটি বুঝতে পেরেছি। সম্পূর্ণ ইন্টারনেটের অগাধ জ্ঞান ও চ্যাটজিপিটির মতো সব প্রশ্নের উত্তর পেতে AI Studio-র Secrets প্যানেলে আপনার ফ্রি Gemini API Key যোগ করে নিতে পারেন। আমি আপনার সেবায় সর্বদা প্রস্তুত!"
            }
        } else {
            return when {
                lower.contains("who are you") || lower.contains("your name") ->
                    "I am Mahi AI, your intelligent and friendly personal assistant. I speak with a natural female voice, support English and Bengali, answer questions, and open apps."

                lower.contains("how are you") ->
                    "I'm doing great, thank you! How can I assist you right now?"

                lower.contains("hello") || lower.contains("hi") || lower.contains("hey mahi") ->
                    "Hello there! I'm Mahi. Ready to help you with anything."

                lower.contains("what time") -> {
                    val time = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())
                    "The current time is $time."
                }

                lower.contains("joke") ->
                    "Why do programmers prefer dark mode? Because light attracts bugs!"

                lower.contains("what can you do") || lower.contains("features") ->
                    "Here is what I can do:\n1. Answer questions in English and Bengali.\n2. Open apps like YouTube, WhatsApp, Facebook, TikTok, Camera.\n3. Draft WhatsApp and social posts.\n4. Speak all responses aloud with a smooth female voice."

                else ->
                    "I heard you! For unlimited frontier intelligence on any topic, add your free Gemini API key in the AI Studio Secrets panel."
            }
        }
    }
}
```

---

## ৩. সরাসরি মোবাইলে ডাউনলোড ও ইন্সটল করার নিয়ম (How to Install on Phone)

১. মোবাইলের ব্রাউজারে থাকা **AI Studio** স্ক্রিনের উপরের ডানদিকের মেনু বা সেটিংস বাটনে চাপ দিন।
২. **Download APK** অথবা **Export Project** চাপুন।
৩. ডাউনলোড হওয়া ফাইলটির নাম হবে `app-release.apk`।
৪. আপনার ফোনের নোটিফিকেশন থেকে ফাইলটিতে চাপ দিন (অথবা ফোনের ফাইল ম্যানেজার থেকে **Downloads** ফোল্ডারে যান)।
৫. যদি ফোন সতর্কবার্তা দেয় *"Install unknown apps"*, তবে **Settings**-এ গিয়ে **Allow** চালু করে দিন।
৬. **Install** চাপুন। ইনস্টলেশন শেষ হলে **Open** চাপুন এবং মাইক্রোফোনের পারমিশন দিন।
